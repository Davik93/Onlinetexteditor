<?php
	echo "<a href='file.zip'>asd</a>";
?>